param($installPath, $toolsPath, $package, $project)

Import-Module (Join-Path $toolsPath Micron.psm1)
