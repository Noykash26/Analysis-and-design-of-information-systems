﻿namespace scouts
{
    partial class logInUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.button_exit = new System.Windows.Forms.Button();
            this.button_signIn = new System.Windows.Forms.Button();
            this.button_signUp = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pages = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.genderComboBox = new System.Windows.Forms.ComboBox();
            this.button_createAccount = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textbox_phone = new System.Windows.Forms.TextBox();
            this.TextBox_email = new System.Windows.Forms.TextBox();
            this.TextBox_nameHeb = new System.Windows.Forms.TextBox();
            this.TextBox_nameENG = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label_nameHeb = new System.Windows.Forms.Label();
            this.lable_name = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button_logIn = new System.Windows.Forms.Button();
            this.signInPassword = new System.Windows.Forms.TextBox();
            this.signInUserName = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pages.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.button_exit);
            this.panel1.Controls.Add(this.button_signIn);
            this.panel1.Controls.Add(this.button_signUp);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(242, 449);
            this.panel1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label2.Location = new System.Drawing.Point(29, 76);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(190, 36);
            this.label2.TabIndex = 3;
            this.label2.Text = "Hello, Guest";
            // 
            // button_exit
            // 
            this.button_exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button_exit.Location = new System.Drawing.Point(24, 234);
            this.button_exit.Margin = new System.Windows.Forms.Padding(2);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(190, 41);
            this.button_exit.TabIndex = 2;
            this.button_exit.Text = "Exit";
            this.button_exit.UseVisualStyleBackColor = true;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // button_signIn
            // 
            this.button_signIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button_signIn.Location = new System.Drawing.Point(24, 182);
            this.button_signIn.Margin = new System.Windows.Forms.Padding(2);
            this.button_signIn.Name = "button_signIn";
            this.button_signIn.Size = new System.Drawing.Size(190, 41);
            this.button_signIn.TabIndex = 1;
            this.button_signIn.Text = "Sign In";
            this.button_signIn.UseVisualStyleBackColor = true;
            this.button_signIn.Click += new System.EventHandler(this.button_signIn_Click);
            // 
            // button_signUp
            // 
            this.button_signUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button_signUp.Location = new System.Drawing.Point(24, 136);
            this.button_signUp.Margin = new System.Windows.Forms.Padding(2);
            this.button_signUp.Name = "button_signUp";
            this.button_signUp.Size = new System.Drawing.Size(190, 38);
            this.button_signUp.TabIndex = 0;
            this.button_signUp.Text = "Sign Up";
            this.button_signUp.UseVisualStyleBackColor = true;
            this.button_signUp.Click += new System.EventHandler(this.button_signUp_Click);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.LightGray;
            this.panel2.Controls.Add(this.pages);
            this.panel2.Location = new System.Drawing.Point(246, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(844, 449);
            this.panel2.TabIndex = 1;
            // 
            // pages
            // 
            this.pages.Controls.Add(this.tabPage1);
            this.pages.Controls.Add(this.tabPage2);
            this.pages.Location = new System.Drawing.Point(131, 44);
            this.pages.Margin = new System.Windows.Forms.Padding(2);
            this.pages.Name = "pages";
            this.pages.SelectedIndex = 0;
            this.pages.Size = new System.Drawing.Size(444, 345);
            this.pages.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.genderComboBox);
            this.tabPage1.Controls.Add(this.button_createAccount);
            this.tabPage1.Controls.Add(this.dateTimePicker1);
            this.tabPage1.Controls.Add(this.textbox_phone);
            this.tabPage1.Controls.Add(this.TextBox_email);
            this.tabPage1.Controls.Add(this.TextBox_nameHeb);
            this.tabPage1.Controls.Add(this.TextBox_nameENG);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label_nameHeb);
            this.tabPage1.Controls.Add(this.lable_name);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage1.Size = new System.Drawing.Size(436, 319);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Sign Up";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // genderComboBox
            // 
            this.genderComboBox.FormattingEnabled = true;
            this.genderComboBox.Location = new System.Drawing.Point(154, 191);
            this.genderComboBox.Margin = new System.Windows.Forms.Padding(2);
            this.genderComboBox.Name = "genderComboBox";
            this.genderComboBox.Size = new System.Drawing.Size(146, 21);
            this.genderComboBox.TabIndex = 5;
            // 
            // button_createAccount
            // 
            this.button_createAccount.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button_createAccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button_createAccount.Location = new System.Drawing.Point(177, 256);
            this.button_createAccount.Margin = new System.Windows.Forms.Padding(2);
            this.button_createAccount.Name = "button_createAccount";
            this.button_createAccount.Size = new System.Drawing.Size(99, 30);
            this.button_createAccount.TabIndex = 13;
            this.button_createAccount.Text = "Create";
            this.button_createAccount.UseVisualStyleBackColor = false;
            this.button_createAccount.Click += new System.EventHandler(this.button_createAccount_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(154, 219);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(146, 20);
            this.dateTimePicker1.TabIndex = 6;
            // 
            // textbox_phone
            // 
            this.textbox_phone.Location = new System.Drawing.Point(154, 162);
            this.textbox_phone.Margin = new System.Windows.Forms.Padding(2);
            this.textbox_phone.MaxLength = 10;
            this.textbox_phone.Name = "textbox_phone";
            this.textbox_phone.Size = new System.Drawing.Size(146, 20);
            this.textbox_phone.TabIndex = 4;
            this.textbox_phone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textbox_phone_KeyPress);
            // 
            // TextBox_email
            // 
            this.TextBox_email.Location = new System.Drawing.Point(154, 132);
            this.TextBox_email.Margin = new System.Windows.Forms.Padding(2);
            this.TextBox_email.Name = "TextBox_email";
            this.TextBox_email.Size = new System.Drawing.Size(146, 20);
            this.TextBox_email.TabIndex = 3;
            // 
            // TextBox_nameHeb
            // 
            this.TextBox_nameHeb.Location = new System.Drawing.Point(154, 105);
            this.TextBox_nameHeb.Margin = new System.Windows.Forms.Padding(2);
            this.TextBox_nameHeb.Name = "TextBox_nameHeb";
            this.TextBox_nameHeb.Size = new System.Drawing.Size(146, 20);
            this.TextBox_nameHeb.TabIndex = 2;
            // 
            // TextBox_nameENG
            // 
            this.TextBox_nameENG.Location = new System.Drawing.Point(154, 78);
            this.TextBox_nameENG.Margin = new System.Windows.Forms.Padding(2);
            this.TextBox_nameENG.Name = "TextBox_nameENG";
            this.TextBox_nameENG.Size = new System.Drawing.Size(146, 20);
            this.TextBox_nameENG.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label7.Location = new System.Drawing.Point(37, 193);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Gender";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label6.Location = new System.Drawing.Point(37, 219);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Birth Date";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label5.Location = new System.Drawing.Point(37, 164);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Phone";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label4.Location = new System.Drawing.Point(37, 132);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Email";
            // 
            // label_nameHeb
            // 
            this.label_nameHeb.AutoSize = true;
            this.label_nameHeb.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label_nameHeb.Location = new System.Drawing.Point(37, 105);
            this.label_nameHeb.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_nameHeb.Name = "label_nameHeb";
            this.label_nameHeb.Size = new System.Drawing.Size(66, 13);
            this.label_nameHeb.TabIndex = 2;
            this.label_nameHeb.Text = "Name (HEB)";
            // 
            // lable_name
            // 
            this.lable_name.AutoSize = true;
            this.lable_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.lable_name.Location = new System.Drawing.Point(36, 78);
            this.lable_name.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lable_name.Name = "lable_name";
            this.lable_name.Size = new System.Drawing.Size(67, 13);
            this.lable_name.TabIndex = 1;
            this.lable_name.Text = "Name (ENG)";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label1.Location = new System.Drawing.Point(94, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(315, 53);
            this.label1.TabIndex = 0;
            this.label1.Text = "Create An Account";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button_logIn);
            this.tabPage2.Controls.Add(this.signInPassword);
            this.tabPage2.Controls.Add(this.signInUserName);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage2.Size = new System.Drawing.Size(436, 319);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Sign In";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button_logIn
            // 
            this.button_logIn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button_logIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button_logIn.Location = new System.Drawing.Point(175, 205);
            this.button_logIn.Margin = new System.Windows.Forms.Padding(2);
            this.button_logIn.Name = "button_logIn";
            this.button_logIn.Size = new System.Drawing.Size(77, 32);
            this.button_logIn.TabIndex = 5;
            this.button_logIn.Text = "Connect";
            this.button_logIn.UseVisualStyleBackColor = false;
            this.button_logIn.Click += new System.EventHandler(this.button_logIn_Click);
            // 
            // signInPassword
            // 
            this.signInPassword.Location = new System.Drawing.Point(161, 146);
            this.signInPassword.Margin = new System.Windows.Forms.Padding(2);
            this.signInPassword.Name = "signInPassword";
            this.signInPassword.Size = new System.Drawing.Size(123, 20);
            this.signInPassword.TabIndex = 2;
            // 
            // signInUserName
            // 
            this.signInUserName.Location = new System.Drawing.Point(161, 95);
            this.signInUserName.Margin = new System.Windows.Forms.Padding(2);
            this.signInUserName.Name = "signInUserName";
            this.signInUserName.Size = new System.Drawing.Size(123, 20);
            this.signInUserName.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(97, 146);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 13);
            this.label10.TabIndex = 2;
            this.label10.Text = "Password";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(92, 98);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 13);
            this.label9.TabIndex = 1;
            this.label9.Text = "User Name";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label8.Location = new System.Drawing.Point(166, 36);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(116, 36);
            this.label8.TabIndex = 0;
            this.label8.Text = "Sign In";
            // 
            // logInUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1093, 449);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(500, 500);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "logInUp";
            this.Text = "Form3";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.pages.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button_signIn;
        private System.Windows.Forms.Button button_signUp;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TabControl pages;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lable_name;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label_nameHeb;
        private System.Windows.Forms.TextBox textbox_phone;
        private System.Windows.Forms.TextBox TextBox_email;
        private System.Windows.Forms.TextBox TextBox_nameHeb;
        private System.Windows.Forms.TextBox TextBox_nameENG;
        private System.Windows.Forms.Button button_createAccount;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button_logIn;
        private System.Windows.Forms.TextBox signInPassword;
        private System.Windows.Forms.TextBox signInUserName;
        private System.Windows.Forms.ComboBox genderComboBox;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.Label label2;
    }
}