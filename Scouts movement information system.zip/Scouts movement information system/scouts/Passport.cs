
using System;


namespace scouts
{
    public class Passport

    {
        public string PassportNumber;
        public DateTime Issue_date;
        private DateTime expiration;
        private string Photo;
        //public void VerifyPassport() {
        //throw new System.Exception("Not implemented");
        //}
        private User have2;
    }

	

	

    

   
}
