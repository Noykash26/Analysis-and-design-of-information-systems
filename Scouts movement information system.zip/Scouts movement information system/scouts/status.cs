using System;
public enum Status {
	Lost,
	Damegd,
	Availabel,
	Borowd,

}
