﻿namespace scouts
{
		public enum VehicleType
	{
			//fixed values
			Male,
			Female,
			Not_binary,

		}
	}