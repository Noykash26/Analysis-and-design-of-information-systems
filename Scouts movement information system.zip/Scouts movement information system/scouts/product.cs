using System;
public class Product {
	public string Id;
	public string Name;

	private Inventory inventory;

	private Price	[] suppliers;

}
