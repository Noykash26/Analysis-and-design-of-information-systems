using System;
public enum Gender {
	//fixed values
	Male,
	male,
	Female,
	female,
	Not_binary,
}
//checkd
