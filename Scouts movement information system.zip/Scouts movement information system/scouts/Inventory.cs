using System;
public class Inventory {
	public string Status;

	public void CalcOptimalReservation() {
		throw new System.Exception("Not implemented");
	}

	private Product[] products;
	private Supplier[] suppliers;

}
